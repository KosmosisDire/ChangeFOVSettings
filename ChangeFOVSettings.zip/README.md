## Description:
Change the field of view and toggle the sprinting FOV increase. These can be changed in realtime from the in-game settings.

## Change Notes:

* 1.0.1
    * updated incorrect github link
    * Updated description

* 1.0.0:
    * Initial release
