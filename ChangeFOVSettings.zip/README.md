## Description:
Allows you to change the camera FOV as well as toggle the increase of FOV while sprinting all from the in-game settings menu. Camera FOV updates in realtime and you can change it anytime so you can make sure you have the correct FOV. 

## Change Notes:

* 1.0.0:
    * Initial release


(Keywords: FOV - Field of View - Camera - Settings - Options)
